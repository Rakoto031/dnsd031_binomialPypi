from setuptools import setup

setup(name='dnsd031_binomialPypi',
      version='0.1',
      description='Gaussian and Binomial distribution',
      packages=['dnsd031_binomialPypi'],
      author= 'Rakoto031',
      zip_safe=False)


